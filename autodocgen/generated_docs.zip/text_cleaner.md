# Documentation for `/content/autodocgen/input_code/testing/pipelines/text_cleaner.py`

## FunctionDef: `clean_text`

 1. Docstring for `clean_text` function:

```python
"""
clean_text(text: str) -> str:

This function cleans a given text by removing all non-alphanumeric and non-whitespace characters.
It is useful for preprocessing text before further analysis, like tokenization or string matching.

Args:
    text (str): The input text to be cleaned.

Returns:
    str: The cleaned text with only alphanumeric characters and whitespaces.
"""
```

2. Short example usage of `clean_text` function:

```python
text = "Welcome 2 Spring Framework! 😎🔎olutil-3.1.0.RELEASE😎"
cleaned_text = clean_text(text)
print(cleaned_text)  # Output: 'Welcome 2 Spring Framework'
```
This example demonstrates that our `clean_text` function successfully removes non-alphanumeric and non-whitespace characters from the input text.

