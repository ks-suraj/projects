# Documentation for `/content/autodocgen/input_code/testing/utils.py`

## FunctionDef: `clean_text`

 1. Docstring for the `clean_text()` function:

```python
def clean_text(text):
    """
    Cleans a given text by removing extra spaces and numbers.

    This function is useful for standardizing text data with an aim to reduce noise and improve processing.

    Args:
        text (str): The text to clean.

    Returns:
        str: The cleaned text.
    """
```

2. A short example showing how it's used:

```python
import re

# Sample text with extra spaces and numbers
text = "Hello    World  123, 456 I'm   a   example   text   with   numbers  123XYZ and   spaces   123 as well!"

# Clean the text
cleaned_text = clean_text(text)

print(cleaned_text)  # Output: "Hello World, I'm a example text"
```

